import streamlit as st
import requests
import json
import csv
import io
import os
# ================================================================
# CONFIG
# ================================================================
st.set_page_config(
    page_title="DocuLens — NLP Document Analyzer",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded"
)

API_URL = os.environ.get("API_URL", "http://localhost:8000")

# ================================================================
# STYLING — Dark professional, React-like feel
# ================================================================
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=DM+Mono:wght@400;500&display=swap');

/* ---- Reset & Base ---- */
html, body, [class*="css"] {
    font-family: 'DM Sans', sans-serif !important;
}

.main .block-container {
    padding: 2rem 2.5rem;
    max-width: 1200px;
}

/* ---- Hide Streamlit chrome ---- */
#MainMenu, footer, header { visibility: hidden; }
.stDeployButton { display: none; }

/* ---- Sidebar ---- */
[data-testid="stSidebar"] {
    background: #0f0f14 !important;
    border-right: 1px solid #1e1e2e;
}

[data-testid="stSidebar"] * {
    color: #a0a0b0 !important;
}

[data-testid="stSidebar"] .stRadio label {
    color: #c0c0d0 !important;
    font-weight: 500;
    font-size: 0.9rem;
}

/* ---- Page background ---- */
.stApp {
    background: #0a0a0f;
    color: #e0e0e8;
}

/* ---- Typography ---- */
.page-title {
    font-size: 2.8rem;
    font-weight: 700;
    color: #ffffff;
    letter-spacing: -1px;
    line-height: 1.1;
    margin-bottom: 0.3rem;
}

.page-subtitle {
    font-size: 1rem;
    color: #606080;
    font-weight: 400;
    margin-bottom: 2.5rem;
    letter-spacing: 0.2px;
}

.section-title {
    font-size: 0.75rem;
    font-weight: 600;
    color: #5050a0;
    text-transform: uppercase;
    letter-spacing: 2px;
    margin-bottom: 1rem;
    margin-top: 2rem;
}

/* ---- Cards ---- */
.glass-card {
    background: #13131f;
    border: 1px solid #1e1e30;
    border-radius: 12px;
    padding: 1.5rem;
    margin-bottom: 1rem;
}

.glass-card-accent {
    background: linear-gradient(135deg, #13131f 0%, #161628 100%);
    border: 1px solid #3030a0;
    border-radius: 12px;
    padding: 1.5rem;
    margin-bottom: 1rem;
}

/* ---- Metric Cards ---- */
.metric-row {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1rem;
    margin-bottom: 2rem;
}

.metric-box {
    background: #13131f;
    border: 1px solid #1e1e30;
    border-radius: 10px;
    padding: 1.2rem;
    text-align: center;
}

.metric-box-value {
    font-size: 1.8rem;
    font-weight: 700;
    color: #7070ff;
    font-family: 'DM Mono', monospace;
    line-height: 1;
    margin-bottom: 0.4rem;
}

.metric-box-label {
    font-size: 0.75rem;
    color: #505070;
    text-transform: uppercase;
    letter-spacing: 1px;
    font-weight: 500;
}

/* ---- Document type badge ---- */
.doc-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 14px;
    border-radius: 100px;
    font-size: 0.8rem;
    font-weight: 600;
    letter-spacing: 0.3px;
}

.badge-invoice   { background: #1a2a1a; color: #4caf50; border: 1px solid #2a4a2a; }
.badge-email     { background: #1a1a2a; color: #7c7cf0; border: 1px solid #2a2a4a; }
.badge-ticket    { background: #2a1a1a; color: #f07070; border: 1px solid #4a2a2a; }
.badge-business  { background: #2a2010; color: #f0b040; border: 1px solid #4a3010; }
.badge-world     { background: #101a2a; color: #40a0f0; border: 1px solid #102a4a; }
.badge-sports    { background: #1a1020; color: #c070f0; border: 1px solid #2a1040; }
.badge-scitech   { background: #0a1a1a; color: #40d0c0; border: 1px solid #0a2a2a; }
.badge-general   { background: #1a1a1a; color: #909090; border: 1px solid #2a2a2a; }

/* ---- Entity tags ---- */
.entity-wrap { display: flex; flex-wrap: wrap; gap: 8px; margin: 0.5rem 0; }

.entity-chip {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 5px 12px;
    border-radius: 8px;
    font-size: 0.82rem;
    font-weight: 500;
    font-family: 'DM Mono', monospace;
}

.chip-PER  { background: #1e1800; color: #ffd54f; border: 1px solid #3e3000; }
.chip-ORG  { background: #001e10; color: #69f0ae; border: 1px solid #003020; }
.chip-LOC  { background: #001020; color: #64b5f6; border: 1px solid #002040; }
.chip-MISC { background: #1a0020; color: #ce93d8; border: 1px solid #300040; }

.chip-type-label {
    font-size: 0.65rem;
    opacity: 0.6;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-left: 1px solid currentColor;
    padding-left: 6px;
    margin-left: 2px;
}

/* ---- Field table ---- */
.field-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 0.6rem;
}

.field-item {
    background: #0e0e18;
    border: 1px solid #1a1a28;
    border-radius: 8px;
    padding: 0.8rem 1rem;
    display: flex;
    flex-direction: column;
    gap: 3px;
}

.field-key {
    font-size: 0.7rem;
    color: #505070;
    text-transform: uppercase;
    letter-spacing: 1px;
    font-weight: 500;
}

.field-val {
    font-size: 0.95rem;
    color: #d0d0e8;
    font-weight: 500;
    font-family: 'DM Mono', monospace;
}

/* ---- Summary block ---- */
.summary-block {
    background: #0e0e18;
    border-left: 3px solid #5050ff;
    border-radius: 0 8px 8px 0;
    padding: 1rem 1.2rem;
    font-size: 0.95rem;
    color: #c0c0d8;
    line-height: 1.7;
    font-style: italic;
}

/* ---- Divider ---- */
.slim-divider {
    height: 1px;
    background: #1a1a28;
    margin: 1.5rem 0;
}

/* ---- History card ---- */
.history-card {
    background: #10101a;
    border: 1px solid #1a1a2a;
    border-radius: 10px;
    padding: 1.2rem 1.5rem;
    margin-bottom: 0.8rem;
    transition: border-color 0.2s;
}

.history-card:hover {
    border-color: #3030a0;
}

/* ---- Search result ---- */
.search-result {
    background: #10101a;
    border: 1px solid #1a1a2a;
    border-radius: 10px;
    padding: 1.2rem 1.5rem;
    margin-bottom: 0.8rem;
}

/* ---- Streamlit overrides ---- */
.stTextArea textarea {
    background: #0e0e18 !important;
    border: 1px solid #2a2a40 !important;
    border-radius: 10px !important;
    color: #d0d0e8 !important;
    font-family: 'DM Mono', monospace !important;
    font-size: 0.9rem !important;
}

.stTextArea textarea:focus {
    border-color: #5050ff !important;
    box-shadow: 0 0 0 2px rgba(80,80,255,0.15) !important;
}

.stTextInput input {
    background: #0e0e18 !important;
    border: 1px solid #2a2a40 !important;
    border-radius: 8px !important;
    color: #d0d0e8 !important;
}

.stButton > button {
    background: #5050ff !important;
    color: white !important;
    border: none !important;
    border-radius: 8px !important;
    font-weight: 600 !important;
    font-family: 'DM Sans', sans-serif !important;
    padding: 0.55rem 1.5rem !important;
    transition: all 0.2s !important;
}

.stButton > button:hover {
    background: #6060ff !important;
    transform: translateY(-1px) !important;
    box-shadow: 0 4px 16px rgba(80,80,255,0.3) !important;
}

div[data-testid="stFileUploader"] {
    background: #0e0e18 !important;
    border: 1px dashed #2a2a40 !important;
    border-radius: 10px !important;
}

.stRadio > div { gap: 0.3rem; }

.stProgress > div > div {
    background: #5050ff !important;
}

.stExpander {
    background: #10101a !important;
    border: 1px solid #1a1a2a !important;
    border-radius: 10px !important;
}

.stAlert {
    background: #0e0e18 !important;
    border-radius: 8px !important;
}

/* ---- Download buttons ---- */
.stDownloadButton > button {
    background: #1a1a2a !important;
    color: #8080ff !important;
    border: 1px solid #3030a0 !important;
    border-radius: 8px !important;
    font-size: 0.85rem !important;
}

.stDownloadButton > button:hover {
    background: #22223a !important;
}
</style>
""", unsafe_allow_html=True)

import os

API_URL = os.environ.get("API_URL", "http://localhost:8000")

# ================================================================
# HELPERS
# ================================================================
DOC_TYPE_CONFIG = {
    "Invoice":       {"icon": "🧾", "badge": "badge-invoice"},
    "Email":         {"icon": "📧", "badge": "badge-email"},
    "Support Ticket":{"icon": "🎫", "badge": "badge-ticket"},
    "Business":      {"icon": "💼", "badge": "badge-business"},
    "World":         {"icon": "🌍", "badge": "badge-world"},
    "Sports":        {"icon": "⚽", "badge": "badge-sports"},
    "Sci/Tech":      {"icon": "🔬", "badge": "badge-scitech"},
}

def doc_badge_html(doc_type: str) -> str:
    cfg = DOC_TYPE_CONFIG.get(doc_type, {"icon": "📄", "badge": "badge-general"})
    return f'<span class="doc-badge {cfg["badge"]}">{cfg["icon"]} {doc_type}</span>'

def entity_chips_html(entities: list) -> str:
    if not entities:
        return '<span style="color:#404060;font-size:0.85rem;">No entities detected</span>'
    chips = []
    for e in entities:
        t = e["type"]
        chips.append(
            f'<span class="entity-chip chip-{t}">'
            f'{e["text"].title()}'
            f'<span class="chip-type-label">{t}</span>'
            f'</span>'
        )
    return f'<div class="entity-wrap">{"".join(chips)}</div>'

def field_grid_html(fields: dict) -> str:
    if not fields:
        return ""
    items = []
    for k, v in fields.items():
        label = k.replace("_", " ").title()
        items.append(
            f'<div class="field-item">'
            f'<span class="field-key">{label}</span>'
            f'<span class="field-val">{v}</span>'
            f'</div>'
        )
    return f'<div class="field-grid">{"".join(items)}</div>'

def api_post(endpoint: str, payload: dict):
    try:
        r = requests.post(f"{API_URL}{endpoint}", json=payload, timeout=90)
        if r.status_code == 200:
            return r.json(), None
        return None, r.json().get("detail", "API error")
    except Exception as e:
        return None, str(e)

def api_get(endpoint: str):
    try:
        r = requests.get(f"{API_URL}{endpoint}", timeout=30)
        if r.status_code == 200:
            return r.json(), None
        return None, "API error"
    except Exception as e:
        return None, str(e)

def extract_text_from_file(uploaded_file):
    ext = uploaded_file.name.split(".")[-1].lower()
    if ext == "txt":
        return uploaded_file.read().decode("utf-8", errors="ignore"), None
    elif ext == "pdf":
        try:
            import pdfplumber
            with pdfplumber.open(io.BytesIO(uploaded_file.read())) as pdf:
                text = "\n".join(
                    p.extract_text() or "" for p in pdf.pages
                ).strip()
            if not text:
                return None, "Could not extract text — PDF may be scanned/image-based."
            return text, None
        except ImportError:
            return None, "pdfplumber not installed. Run: pip install pdfplumber"
        except Exception as e:
            return None, str(e)
    return None, "Unsupported file type"

# ================================================================
# SIDEBAR
# ================================================================
with st.sidebar:
    st.markdown("""
    <div style="padding:1.5rem 0 1rem;">
        <div style="font-size:1.4rem;font-weight:700;color:#fff;letter-spacing:-0.5px;">🔬 DocuLens</div>
        <div style="font-size:0.75rem;color:#404060;margin-top:4px;letter-spacing:1px;text-transform:uppercase;">NLP Document Analyzer</div>
    </div>
    <div style="height:1px;background:#1a1a28;margin-bottom:1.5rem;"></div>
    """, unsafe_allow_html=True)

    page = st.radio(
        "Navigation",
        ["Analyze", "History", "Search", "Dashboard"],
        label_visibility="collapsed"
    )

    st.markdown("""
    <div style="height:1px;background:#1a1a28;margin:1.5rem 0;"></div>
    <div style="font-size:0.7rem;color:#303050;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:1rem;">Models</div>
    <div style="font-size:0.8rem;color:#505070;line-height:2;">
        DistilBERT · NER · F1 92.6%<br>
        BERT-base · Classify · F1 92.8%<br>
        MiniLM-L6 · Embeddings<br>
        LangGraph · Orchestration
    </div>
    <div style="height:1px;background:#1a1a28;margin:1.5rem 0;"></div>
    <div style="font-size:0.7rem;color:#303050;">Supports: PDF · TXT · Plain Text</div>
    """, unsafe_allow_html=True)


# ================================================================
# PAGE: ANALYZE
# ================================================================
if page == "Analyze":
    st.markdown('<div class="page-title">Document Intelligence</div>', unsafe_allow_html=True)
    st.markdown('<div class="page-subtitle">Upload or paste any business document — invoices, emails, tickets, articles</div>', unsafe_allow_html=True)

    input_tab = st.radio("Input method", ["✏️ Paste Text", "📎 Upload File"], horizontal=True, label_visibility="collapsed")

    text_input = ""

    if input_tab == "✏️ Paste Text":
        text_input = st.text_area(
            "Document content",
            height=220,
            placeholder="Paste your invoice, email, support ticket, or any document here...",
            label_visibility="collapsed"
        )
    else:
        uploaded = st.file_uploader(
            "Upload document",
            type=["pdf", "txt"],
            label_visibility="collapsed",
            help="PDF or plain text files"
        )
        if uploaded:
            with st.spinner("Extracting text..."):
                text_input, err = extract_text_from_file(uploaded)
            if err:
                st.error(f"❌ {err}")
            else:
                st.success(f"✅ {uploaded.name} — {len(text_input):,} characters extracted")
                with st.expander("Preview extracted text"):
                    st.code(text_input[:800], language=None)

    col_btn, col_info = st.columns([1, 4])
    with col_btn:
        run = st.button("🔍 Analyze Document", use_container_width=True)

    if run:
        if not text_input or not text_input.strip():
            st.error("Please provide document content first.")
        else:
            with st.spinner("Running NLP pipeline..."):
                result, error = api_post("/analyze", {"text": text_input})

            if error:
                st.error(f"❌ Pipeline error: {error}")
            else:
                # ---- Header ----
                st.markdown('<div class="slim-divider"></div>', unsafe_allow_html=True)
                hcol1, hcol2 = st.columns([3, 1])
                with hcol1:
                    st.markdown(
                        f'<div style="display:flex;align-items:center;gap:12px;margin-bottom:0.5rem;">'
                        f'<span style="font-size:1.4rem;font-weight:700;color:#fff;">Analysis Complete</span>'
                        f'{doc_badge_html(result["doc_type"])}'
                        f'</div>',
                        unsafe_allow_html=True
                    )
                with hcol2:
                    st.markdown(f'<div style="text-align:right;color:#404060;font-size:0.8rem;font-family:DM Mono;padding-top:8px;">ID: {result["doc_id"]}</div>', unsafe_allow_html=True)

                # ---- Metrics ----
                m1, m2, m3, m4 = st.columns(4)
                with m1:
                    st.markdown(f'<div class="metric-box"><div class="metric-box-value">{result["doc_type"].split("/")[0]}</div><div class="metric-box-label">Document Type</div></div>', unsafe_allow_html=True)
                with m2:
                    conf_pct = f'{result["confidence"]*100:.1f}%'
                    st.markdown(f'<div class="metric-box"><div class="metric-box-value">{conf_pct}</div><div class="metric-box-label">Confidence</div></div>', unsafe_allow_html=True)
                with m3:
                    st.markdown(f'<div class="metric-box"><div class="metric-box-value">{len(result["entities"])}</div><div class="metric-box-label">Entities Found</div></div>', unsafe_allow_html=True)
                with m4:
                    wc = len(text_input.split())
                    st.markdown(f'<div class="metric-box"><div class="metric-box-value">{wc}</div><div class="metric-box-label">Word Count</div></div>', unsafe_allow_html=True)

                st.markdown('<div class="slim-divider"></div>', unsafe_allow_html=True)

                # ---- Extracted Fields ----
                if result.get("extracted_fields"):
                    st.markdown('<div class="section-title">Extracted Fields</div>', unsafe_allow_html=True)
                    st.markdown(
                        f'<div class="glass-card">{field_grid_html(result["extracted_fields"])}</div>',
                        unsafe_allow_html=True
                    )

                # ---- Summary ----
                st.markdown('<div class="section-title">AI Summary</div>', unsafe_allow_html=True)
                st.markdown(
                    f'<div class="summary-block">{result["summary"]}</div>',
                    unsafe_allow_html=True
                )

                # ---- Entities ----
                st.markdown('<div class="section-title">Named Entities</div>', unsafe_allow_html=True)
                st.markdown(
                    f'<div class="glass-card">{entity_chips_html(result["entities"])}</div>',
                    unsafe_allow_html=True
                )

                # ---- Export ----
                st.markdown('<div class="section-title">Export</div>', unsafe_allow_html=True)
                ex1, ex2 = st.columns(2)
                with ex1:
                    st.download_button(
                        "⬇️ Download JSON",
                        data=json.dumps(result, indent=2),
                        file_name=f"docuLens_{result['doc_id']}.json",
                        mime="application/json",
                        use_container_width=True
                    )
                with ex2:
                    buf = io.StringIO()
                    w = csv.writer(buf)
                    w.writerow(["Field", "Value"])
                    w.writerow(["Document ID", result["doc_id"]])
                    w.writerow(["Document Type", result["doc_type"]])
                    w.writerow(["Confidence", conf_pct])
                    w.writerow(["Summary", result["summary"]])
                    for ent in result["entities"]:
                        w.writerow([f"Entity ({ent['type']})", ent["text"]])
                    for k, v in result.get("extracted_fields", {}).items():
                        w.writerow([k.replace("_", " ").title(), v])
                    st.download_button(
                        "⬇️ Download CSV",
                        data=buf.getvalue(),
                        file_name=f"docuLens_{result['doc_id']}.csv",
                        mime="text/csv",
                        use_container_width=True
                    )


# ================================================================
# PAGE: HISTORY
# ================================================================
elif page == "History":
    st.markdown('<div class="page-title">Document History</div>', unsafe_allow_html=True)
    st.markdown('<div class="page-subtitle">All previously analyzed documents</div>', unsafe_allow_html=True)

    hcol1, hcol2 = st.columns([5, 1])
    with hcol2:
        if st.button("↻ Refresh"):
            st.rerun()

    data, error = api_get("/documents")

    if error:
        st.error(f"❌ {error}")
    elif not data or data["total"] == 0:
        st.markdown('<div class="glass-card" style="text-align:center;color:#404060;padding:3rem;">No documents analyzed yet. Go to Analyze to get started.</div>', unsafe_allow_html=True)
    else:
        st.markdown(f'<div style="color:#505070;font-size:0.85rem;margin-bottom:1.5rem;">{data["total"]} document{"s" if data["total"] != 1 else ""} in database</div>', unsafe_allow_html=True)

        for doc in data["documents"]:
            cfg = DOC_TYPE_CONFIG.get(doc["doc_type"], {"icon": "📄", "badge": "badge-general"})
            with st.expander(f'{cfg["icon"]}  {doc["doc_type"]} · {doc["text_preview"][:60]}...'):
                hc1, hc2, hc3 = st.columns(3)
                with hc1:
                    st.markdown(f'<div class="field-item"><span class="field-key">Type</span><span class="field-val">{doc["doc_type"]}</span></div>', unsafe_allow_html=True)
                with hc2:
                    st.markdown(f'<div class="field-item"><span class="field-key">Confidence</span><span class="field-val">{doc["confidence"]*100:.1f}%</span></div>', unsafe_allow_html=True)
                with hc3:
                    st.markdown(f'<div class="field-item"><span class="field-key">Analyzed At</span><span class="field-val">{doc["created_at"]}</span></div>', unsafe_allow_html=True)

                st.markdown('<div style="height:0.8rem;"></div>', unsafe_allow_html=True)

                if doc.get("extracted_fields"):
                    st.markdown(field_grid_html(doc["extracted_fields"]), unsafe_allow_html=True)
                    st.markdown('<div style="height:0.5rem;"></div>', unsafe_allow_html=True)

                st.markdown(f'<div class="summary-block">{doc["summary"]}</div>', unsafe_allow_html=True)
                st.markdown('<div style="height:0.5rem;"></div>', unsafe_allow_html=True)
                st.markdown(entity_chips_html(doc["entities"]), unsafe_allow_html=True)


# ================================================================
# PAGE: SEARCH
# ================================================================
elif page == "Search":
    st.markdown('<div class="page-title">Semantic Search</div>', unsafe_allow_html=True)
    st.markdown('<div class="page-subtitle">Search across all analyzed documents by meaning, not keywords</div>', unsafe_allow_html=True)

    query = st.text_input("Search query", placeholder="e.g. unpaid invoices, login issues, quarterly earnings...", label_visibility="collapsed")
    sc1, sc2 = st.columns([4, 1])
    with sc1:
        n_results = st.slider("Results", 1, 10, 5, label_visibility="collapsed")
    with sc2:
        search_btn = st.button("🔍 Search", use_container_width=True)

    if search_btn:
        if not query.strip():
            st.error("Enter a search query first.")
        else:
            with st.spinner("Searching vector database..."):
                results, error = api_post("/search", {"query": query, "n_results": n_results})

            if error:
                st.error(f"❌ {error}")
            elif not results or results["total"] == 0:
                st.info("No matching documents found. Analyze more documents first.")
            else:
                st.markdown(f'<div style="color:#505070;font-size:0.85rem;margin-bottom:1.5rem;">Found {results["total"]} result{"s" if results["total"] != 1 else ""} for &ldquo;{query}&rdquo;</div>', unsafe_allow_html=True)
                for i, doc in enumerate(results["results"], 1):
                    cfg = DOC_TYPE_CONFIG.get(doc["doc_type"], {"icon": "📄", "badge": "badge-general"})
                    st.markdown(f"""
                    <div class="search-result">
                        <div style="display:flex;align-items:center;gap:10px;margin-bottom:0.8rem;">
                            <span style="color:#404060;font-size:0.8rem;font-family:DM Mono;">#{i}</span>
                            {doc_badge_html(doc["doc_type"])}
                        </div>
                        <div class="summary-block" style="margin-bottom:0.8rem;">{doc["summary"]}</div>
                        <div style="font-size:0.82rem;color:#404060;font-family:DM Mono;line-height:1.6;">{doc["text_preview"]}</div>
                    </div>
                    """, unsafe_allow_html=True)


# ================================================================
# PAGE: DASHBOARD
# ================================================================
elif page == "Dashboard":
    st.markdown('<div class="page-title">Analytics</div>', unsafe_allow_html=True)
    st.markdown('<div class="page-subtitle">System performance and document statistics</div>', unsafe_allow_html=True)

    dcol1, dcol2 = st.columns([5, 1])
    with dcol2:
        if st.button("↻ Refresh"):
            st.rerun()

    stats, error = api_get("/stats")

    if error:
        st.error(f"❌ {error}")
    else:
        # KPIs
        k1, k2, k3 = st.columns(3)
        with k1:
            st.markdown(f'<div class="metric-box"><div class="metric-box-value">{stats["total_documents"]}</div><div class="metric-box-label">Total Documents</div></div>', unsafe_allow_html=True)
        with k2:
            st.markdown(f'<div class="metric-box"><div class="metric-box-value">{stats["vector_store_count"]}</div><div class="metric-box-label">Vectors Stored</div></div>', unsafe_allow_html=True)
        with k3:
            st.markdown(f'<div class="metric-box"><div class="metric-box-value">4</div><div class="metric-box-label">Active Models</div></div>', unsafe_allow_html=True)

        st.markdown('<div class="slim-divider"></div>', unsafe_allow_html=True)

        # Document type breakdown
        if stats["documents_by_type"]:
            st.markdown('<div class="section-title">Document Breakdown</div>', unsafe_allow_html=True)
            total = stats["total_documents"] or 1
            for doc_type, count in stats["documents_by_type"].items():
                pct = count / total
                cfg = DOC_TYPE_CONFIG.get(doc_type, {"icon": "📄", "badge": "badge-general"})
                st.markdown(f"""
                <div style="margin-bottom:1rem;">
                    <div style="display:flex;justify-content:space-between;margin-bottom:6px;">
                        <span style="color:#c0c0d8;font-size:0.9rem;font-weight:500;">{cfg["icon"]} {doc_type}</span>
                        <span style="color:#5050a0;font-size:0.85rem;font-family:DM Mono;">{count} · {pct*100:.0f}%</span>
                    </div>
                    <div style="height:6px;background:#1a1a28;border-radius:3px;overflow:hidden;">
                        <div style="height:100%;width:{pct*100}%;background:linear-gradient(90deg,#5050ff,#8080ff);border-radius:3px;"></div>
                    </div>
                </div>
                """, unsafe_allow_html=True)

        st.markdown('<div class="slim-divider"></div>', unsafe_allow_html=True)

        # Model performance
        st.markdown('<div class="section-title">Model Performance</div>', unsafe_allow_html=True)
        mc1, mc2 = st.columns(2)
        with mc1:
            st.markdown("""
            <div class="glass-card">
                <div style="font-size:0.75rem;color:#505070;text-transform:uppercase;letter-spacing:1px;margin-bottom:0.5rem;">NER Model</div>
                <div style="font-size:1rem;color:#fff;font-weight:600;margin-bottom:0.3rem;">DistilBERT</div>
                <div style="font-size:0.8rem;color:#404060;margin-bottom:0.8rem;">Trained on WikiANN English</div>
            </div>
            """, unsafe_allow_html=True)
            st.progress(0.9263, text="F1 Score: 92.63%")
        with mc2:
            st.markdown("""
            <div class="glass-card">
                <div style="font-size:0.75rem;color:#505070;text-transform:uppercase;letter-spacing:1px;margin-bottom:0.5rem;">Classifier</div>
                <div style="font-size:1rem;color:#fff;font-weight:600;margin-bottom:0.3rem;">BERT-base</div>
                <div style="font-size:0.8rem;color:#404060;margin-bottom:0.8rem;">Trained on AG News · 4 classes</div>
            </div>
            """, unsafe_allow_html=True)
            st.progress(0.9277, text="F1 Score: 92.77%")
