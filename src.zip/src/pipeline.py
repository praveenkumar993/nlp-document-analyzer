import torch
import re
import os
import json
from transformers import (
    DistilBertTokenizerFast,
    DistilBertForTokenClassification,
    BertTokenizerFast,
    BertForSequenceClassification,
    pipeline
)
from langgraph.graph import StateGraph, END
from typing import TypedDict, List, Dict, Any
import chromadb
from sentence_transformers import SentenceTransformer
from dotenv import load_dotenv

load_dotenv()

# ---- Labels ----
NER_LABELS = ["O", "B-PER", "I-PER", "B-ORG", "I-ORG", "B-LOC", "I-LOC"]
CLASSIFIER_LABELS = ["World", "Sports", "Business", "Sci/Tech"]

# ---- Device ----
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {DEVICE}")

# ---- Load Models ----
print("Loading NER model...")
ner_tokenizer = DistilBertTokenizerFast.from_pretrained("models/ner_model")
ner_model = DistilBertForTokenClassification.from_pretrained("models/ner_model")
ner_model.to(DEVICE)
ner_model.eval()

print("Loading Classifier model...")
cls_tokenizer = BertTokenizerFast.from_pretrained("models/classifier_model")
cls_model = BertForSequenceClassification.from_pretrained("models/classifier_model")
cls_model.to(DEVICE)
cls_model.eval()

print("Loading Sentence Transformer...")
embedder = SentenceTransformer("all-MiniLM-L6-v2")

print("Loading DistilBART Summarizer...")
bart_summarizer = pipeline(
    task="summarization",
    model="sshleifer/distilbart-cnn-12-6",
    device=-1
)

print("Setting up ChromaDB...")
chroma_client = chromadb.Client()
collection = chroma_client.get_or_create_collection("documents")

print("All models loaded!")


# ================================================================
# DOCUMENT TYPE DETECTION — Rule-based first, ML fallback
# ================================================================
def detect_document_type(text: str) -> str:
    text_lower = text.lower()

    invoice_keywords = [
        "invoice", "total due", "payment due", "invoice number",
        "bill to", "ship to", "subtotal", "amount due",
        "purchase order", "invoice date", "due date", "tax", "receipt"
    ]
    email_keywords = [
        "dear", "regards", "sincerely", "best regards",
        "subject:", "please find", "attached", "let me know",
        "thank you for", "hi ", "hello ", "greetings"
    ]
    ticket_keywords = [
        "ticket", "priority", "bug", "assigned to",
        "reported by", "severity", "incident", "resolve",
        "support request", "status:", "issue #", "case #"
    ]

    invoice_score = sum(1 for kw in invoice_keywords if kw in text_lower)
    email_score = sum(1 for kw in email_keywords if kw in text_lower)
    ticket_score = sum(1 for kw in ticket_keywords if kw in text_lower)

    scores = {"Invoice": invoice_score, "Email": email_score, "Support Ticket": ticket_score}
    max_type = max(scores, key=scores.get)
    max_score = scores[max_type]

    return max_type if max_score >= 2 else "General"


# ================================================================
# FIELD EXTRACTORS — per document type
# ================================================================
def extract_invoice_fields(text: str) -> dict:
    fields = {}

    patterns = {
        "invoice_number": r'invoice\s*(?:number|#|no\.?)\s*[:\-]?\s*([A-Z0-9\-]{3,})',
        "order_number":   r'order\s*(?:number|#|no\.?)?\s*[:\-]?\s*([A-Z0-9\-]{3,})',
        "total_due": r'total\s*due\s*[:\-]?\s*\$?([\d,]+\.?\d*)',
        "tax":            r'\btax\b\s*[:\-]?\s*\$?([\d,]+\.?\d*)',
        "sub_total":      r'sub\s*total\s*[:\-]?\s*\$?([\d,]+\.?\d*)',
        "invoice_date":   r'invoice\s*date\s*[:\-]?\s*([A-Za-z]+\s+\d+,?\s*\d{4}|\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})',
        "due_date":       r'due\s*date\s*[:\-]?\s*([A-Za-z]+\s+\d+,?\s*\d{4}|\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})',
    }

    for field, pattern in patterns.items():
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            val = match.group(1).strip()
            if field in ["total_due", "tax", "sub_total"]:
                val = f"${val}"
            fields[field] = val

    # Vendor — line after "From:"
    from_match = re.search(r'(?:^|\n)\s*from\s*:\s*\n?\s*(.+)', text, re.IGNORECASE)
    if from_match:
        fields["vendor"] = from_match.group(1).strip()

    # Client — line after "To:"
    to_match = re.search(r'(?:^|\n)\s*to\s*:\s*\n?\s*(.+)', text, re.IGNORECASE)
    if to_match:
        fields["client"] = to_match.group(1).strip()

    return fields


def extract_email_fields(text: str) -> dict:
    fields = {}
    lines = text.strip().split("\n")

    for line in lines[:10]:  # only check first 10 lines for headers
        stripped = line.strip()
        lower = stripped.lower()
        if lower.startswith("subject:"):
            fields["subject"] = stripped.split(":", 1)[1].strip()
        elif lower.startswith("from:"):
            fields["from"] = stripped.split(":", 1)[1].strip()
        elif lower.startswith("to:"):
            fields["to"] = stripped.split(":", 1)[1].strip()
        elif lower.startswith("cc:"):
            fields["cc"] = stripped.split(":", 1)[1].strip()

    text_lower = text.lower()
    if any(w in text_lower for w in ["complaint", "unhappy", "disappointed", "not satisfied", "issue with"]):
        fields["intent"] = "Complaint"
    elif any(w in text_lower for w in ["follow up", "following up", "checking in", "any update"]):
        fields["intent"] = "Follow Up"
    elif any(w in text_lower for w in ["thank you", "thanks", "appreciate", "grateful"]):
        fields["intent"] = "Appreciation"
    elif any(w in text_lower for w in ["please find", "attached", "quotation", "proposal", "request"]):
        fields["intent"] = "Request"
    else:
        fields["intent"] = "General"

    return fields


def extract_ticket_fields(text: str) -> dict:
    fields = {}

    ticket_match = re.search(r'(?:ticket|case|issue)\s*[#:\-]?\s*([A-Z0-9\-]+)', text, re.IGNORECASE)
    if ticket_match:
        fields["ticket_id"] = ticket_match.group(1).strip()

    priority_match = re.search(r'priority\s*[:\-]?\s*(low|medium|high|critical|urgent)', text, re.IGNORECASE)
    if priority_match:
        fields["priority"] = priority_match.group(1).capitalize()
    else:
        text_lower = text.lower()
        if any(w in text_lower for w in ["urgent", "critical", "asap", "immediately", "blocker"]):
            fields["priority"] = "High"
        elif any(w in text_lower for w in ["low priority", "minor", "whenever possible"]):
            fields["priority"] = "Low"
        else:
            fields["priority"] = "Medium"

    status_match = re.search(r'status\s*[:\-]?\s*(open|closed|pending|resolved|in\s*progress)', text, re.IGNORECASE)
    fields["status"] = status_match.group(1).strip().capitalize() if status_match else "Open"

    text_lower = text.lower()
    if any(w in text_lower for w in ["login", "password", "access", "authentication", "permission"]):
        fields["issue_type"] = "Access Issue"
    elif any(w in text_lower for w in ["crash", "error", "bug", "not working", "broken", "failed"]):
        fields["issue_type"] = "Bug Report"
    elif any(w in text_lower for w in ["slow", "performance", "timeout", "latency", "hang"]):
        fields["issue_type"] = "Performance Issue"
    elif any(w in text_lower for w in ["install", "setup", "configure", "deployment"]):
        fields["issue_type"] = "Installation Issue"
    else:
        fields["issue_type"] = "General Issue"

    assigned_match = re.search(r'assigned\s*to\s*[:\-]?\s*(.+?)(?:\n|$)', text, re.IGNORECASE)
    if assigned_match:
        fields["assigned_to"] = assigned_match.group(1).strip()

    return fields


def extract_fields(doc_type: str, text: str) -> dict:
    if doc_type == "Invoice":
        return extract_invoice_fields(text)
    elif doc_type == "Email":
        return extract_email_fields(text)
    elif doc_type == "Support Ticket":
        return extract_ticket_fields(text)
    return {}


# ================================================================
# ENTITY CLEANING
# ================================================================
NOISE_ENTITIES = {
    "office supplies", "web design", "sample", "services", "payment",
    "invoice", "total", "tax", "sub", "amount", "date", "number",
    "dear", "regards", "sincerely", "hello", "hi", "subject"
}

def clean_entities(entities: list) -> list:
    cleaned = []
    seen = set()
    for entity in entities:
        text = entity["text"].strip()
        if len(text) < 3:
            continue
        if text.startswith("##"):
            continue
        if text.lower() in NOISE_ENTITIES:
            continue
        if text.lower() in seen:
            continue
        seen.add(text.lower())
        cleaned.append(entity)
    return cleaned


# ================================================================
# SUMMARIZER — document-type aware, never copies text
# ================================================================
def generate_summary(doc_type: str, text: str, entities: list, extracted_fields: dict) -> str:
    per_entities = [e["text"].title() for e in entities if e["type"] == "PER"]
    org_entities = [e["text"].title() for e in entities if e["type"] == "ORG"]
    loc_entities = [e["text"].title() for e in entities if e["type"] == "LOC"]

    if doc_type == "Invoice":
        vendor = extracted_fields.get("vendor", org_entities[0] if org_entities else "Unknown vendor")
        client = extracted_fields.get("client", "the client")
        total = extracted_fields.get("total_due", "N/A")
        inv_num = extracted_fields.get("invoice_number", "N/A")
        due = extracted_fields.get("due_date", "N/A")
        inv_date = extracted_fields.get("invoice_date", "N/A")
        return (
            f"Invoice {inv_num} was issued by {vendor} "
            f"to {client} on {inv_date}. "
            f"The total amount due is {total}, "
            f"with a payment deadline of {due}."
        )

    elif doc_type == "Email":
        subject = extracted_fields.get("subject", "")
        sender = extracted_fields.get("from", per_entities[0] if per_entities else "the sender")
        intent = extracted_fields.get("intent", "General")
        org = org_entities[0] if org_entities else ""
        parts = [f"{intent} email"]
        if subject:
            parts.append(f"regarding \"{subject}\"")
        if sender:
            parts.append(f"from {sender}")
        if org:
            parts.append(f"at {org}")
        if loc_entities:
            parts.append(f"based in {loc_entities[0]}")
        return " ".join(parts) + "."

    elif doc_type == "Support Ticket":
        ticket_id = extracted_fields.get("ticket_id", "")
        priority = extracted_fields.get("priority", "Medium")
        issue_type = extracted_fields.get("issue_type", "General Issue")
        status = extracted_fields.get("status", "Open")
        assigned = extracted_fields.get("assigned_to", "")
        sentences = [s.strip() for s in text.split(".") if len(s.strip()) > 20]
        detail = sentences[0] if sentences else ""
        summary = f"{priority} priority {issue_type}"
        if ticket_id:
            summary += f" (#{ticket_id})"
        summary += f". Status: {status}."
        if assigned:
            summary += f" Assigned to {assigned}."
        if detail:
            summary += f" {detail}."
        return summary

    else:
        # News / General — extractive fallback
        sentences = [s.strip() for s in text.split(".") if len(s.strip()) > 25]
        if not sentences:
            return text[:200].strip()
        if len(sentences) == 1:
            return sentences[0] + "."

        all_entities = [e["text"].lower() for e in entities]
        scored = []
        for i, sent in enumerate(sentences):
            score = 0
            if i == 0:
                score += 4
            for ent in all_entities:
                if ent in sent.lower():
                    score += 2
            if len(sent.split()) < 30:
                score += 1
            scored.append((score, i, sent))

        top = sorted(scored, reverse=True)[:2]
        ordered = [s for _, _, s in sorted(top, key=lambda x: x[1])]
        return ". ".join(ordered).strip() + "."

# ================================================================
# LLM SUMMARY ENHANCER
# ================================================================
def enhance_summary_with_llm(summary: str, doc_type: str) -> str:

    try:

        result = bart_summarizer(
            summary,
            max_length=100,
            min_length=20,
            do_sample=False,
            truncation=True
        )

        enhanced_summary = result[0]["summary_text"].strip()

        # Cleanup spaces before punctuation
        enhanced_summary = re.sub(r'\s+([.,])', r'\1', enhanced_summary)

        # Remove duplicate words
        enhanced_summary = re.sub(
            r'\b(Invoice|Email|Ticket)\s+\1\b',
            r'\1',
            enhanced_summary
        )

        return enhanced_summary

    except Exception as e:
        print(f"Summary enhancement failed: {e}")
        return summary
# ================================================================
# LANGGRAPH STATE
# ================================================================
class DocumentState(TypedDict):
    text: str
    entities: List[Dict[str, str]]
    doc_type: str
    confidence: float
    summary: str
    raw_summary: str
    doc_id: str
    extracted_fields: Dict[str, Any]
    error: str


# ================================================================
# PIPELINE NODES
# ================================================================
def preprocess(state: DocumentState) -> DocumentState:
    text = state["text"].strip()
    text = re.sub(r'[ \t]+', ' ', text)   # collapse spaces/tabs
    text = re.sub(r'\n{3,}', '\n\n', text)  # collapse excessive newlines
    state["text"] = text
    state["doc_id"] = str(abs(hash(text)))[:8]
    return state


def run_ner(state: DocumentState) -> DocumentState:
    text = state["text"]
    inputs = ner_tokenizer(
        text,
        return_tensors="pt",
        truncation=True,
        max_length=128,
        padding=True
    ).to(DEVICE)

    with torch.no_grad():
        outputs = ner_model(**inputs)

    predictions = torch.argmax(outputs.logits, dim=-1).squeeze().tolist()
    tokens = ner_tokenizer.convert_ids_to_tokens(inputs["input_ids"].squeeze().tolist())

    entities = []
    current_entity = None

    for token, pred in zip(tokens, predictions):
        if token in ["[CLS]", "[SEP]", "[PAD]"]:
            continue
        label = NER_LABELS[pred]
        if label.startswith("B-"):
            if current_entity:
                entities.append(current_entity)
            current_entity = {"text": token, "type": label[2:]}
        elif label.startswith("I-") and current_entity:
            if token.startswith("##"):
                current_entity["text"] += token[2:]
            else:
                current_entity["text"] += " " + token
        else:
            if current_entity:
                entities.append(current_entity)
                current_entity = None

    if current_entity:
        entities.append(current_entity)

    state["entities"] = clean_entities(entities)
    return state


def run_classifier(state: DocumentState) -> DocumentState:
    text = state["text"]
    rule_type = detect_document_type(text)

    if rule_type != "General":
        state["doc_type"] = rule_type
        state["confidence"] = 1.0
    else:
        inputs = cls_tokenizer(
            text,
            return_tensors="pt",
            truncation=True,
            max_length=256,
            padding=True
        ).to(DEVICE)
        with torch.no_grad():
            outputs = cls_model(**inputs)
        probs = torch.softmax(outputs.logits, dim=-1).squeeze()
        pred_id = torch.argmax(probs).item()
        state["doc_type"] = CLASSIFIER_LABELS[pred_id]
        state["confidence"] = round(probs[pred_id].item(), 4)

    state["extracted_fields"] = extract_fields(state["doc_type"], text)
    return state


def run_summarizer(state: DocumentState) -> DocumentState:

    # Step 1 — Generate structured summary
    raw_summary = generate_summary(
        state["doc_type"],
        state["text"],
        state["entities"],
        state["extracted_fields"]
    )

    # Step 2 — Enhance using BART
    enhanced_summary = enhance_summary_with_llm(
        raw_summary,
        state["doc_type"]
    )

    # Store enhanced summary
    state["summary"] = enhanced_summary

    # Optional: store raw summary also
    state["raw_summary"] = raw_summary

    return state


def run_vector_store(state: DocumentState) -> DocumentState:
    text = state["text"]
    doc_id = state["doc_id"]
    embedding = embedder.encode(text).tolist()
    collection.upsert(
        documents=[text],
        embeddings=[embedding],
        ids=[doc_id],
        metadatas=[{
            "doc_type": state["doc_type"],
            "summary": state["summary"]
        }]
    )
    return state


# ================================================================
# BUILD AND RUN PIPELINE
# ================================================================
def build_pipeline():
    graph = StateGraph(DocumentState)
    graph.add_node("preprocess", preprocess)
    graph.add_node("ner", run_ner)
    graph.add_node("classifier", run_classifier)
    graph.add_node("summarizer", run_summarizer)
    graph.add_node("vector_store", run_vector_store)
    graph.set_entry_point("preprocess")
    graph.add_edge("preprocess", "ner")
    graph.add_edge("ner", "classifier")
    graph.add_edge("classifier", "summarizer")
    graph.add_edge("summarizer", "vector_store")
    graph.add_edge("vector_store", END)
    return graph.compile()


def analyze_document(text: str) -> Dict[str, Any]:
    pipeline = build_pipeline()
    initial_state = DocumentState(
        text=text,
        entities=[],
        doc_type="",
        confidence=0.0,
        summary="",
        raw_summary="",
        doc_id="",
        extracted_fields={},
        error=""
    )
    result = pipeline.invoke(initial_state)
    return {
        "doc_id": result["doc_id"],
        "doc_type": result["doc_type"],
        "confidence": result["confidence"],
        "entities": result["entities"],
        "summary": result["summary"],
        "raw_summary": result["raw_summary"],
        "extracted_fields": result["extracted_fields"]
    }
